import math
import random
def Miller(n):
    k = 0
    q = n - 1
    while q % 2 == 0:
        q = q/2
        k = k + 1
    q = int(q)

    # find a < n wich (a,n) = 1
    a = random.randint(2, n-2)
    flag = 0
    if pow(a, q, n) == 1:
        return 0
    else:
        for j in range(0,k):
            if pow(a, q*pow(2, j), n) == n-1:
                return 0
        return 1


a = 0
n = int(input())
for i in range(0, 10):
    a += Miller(n)
if a > 0:
    print("composit")
else:
    print("inconclusive")
